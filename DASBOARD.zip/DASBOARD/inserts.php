<!--add your functions here! you can follow my format-->
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>wmdashboard</title>
    <!-- plugins:css -->
    <link rel="stylesheet" href="assets/vendors/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="assets/vendors/css/vendor.bundle.base.css">
    <!-- endinject -->
    <!-- Plugin css for this page -->
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <!-- endinject -->
    <!-- Layout styles -->
    <link rel="stylesheet" href="assets/css/style.css">
    <!-- End layout styles -->
    <link rel="shortcut icon" href="assets/images/favicon.png" />
  </head>
  <body>
<?php include "includes/connector.php";
session_start();
// initializing variables
$username = "";
$email    = "";
$errors = array();
$_SESSION['success'] = ""; 

if (isset($_POST['reg_user'])) {
 $image = $_FILES['img']['name'];
// receive all input values from the form
$username = mysqli_real_escape_string($wmdb, $_POST['username']);
$email = mysqli_real_escape_string($wmdb, $_POST['email']);
$password_1 = mysqli_real_escape_string($wmdb, $_POST['password_1']);
$password_2 = mysqli_real_escape_string($wmdb, $_POST['password_2']);
// form validation: ensure that the form is correctly filled ...
//handle profile picture upload
$target = "uploads/userprofiles/".basename($image);
// by adding (array_push()) corresponding error unto $errors array
if (empty($username)) { array_push($errors, "Username is required"); }
if (empty($email)) { array_push($errors, "Email is required"); }
if (empty($password_1)) { array_push($errors, "Password is required"); }
if ($password_1 != $password_2) {
array_push($errors, "The two passwords do not match");
}
// first check the database to make sure
// a user does not already exist with the same username and/or email
$user_check_query = "SELECT * FROM users WHERE username='$username' OR email='$email' LIMIT 1";
$result = mysqli_query($wmdb, $user_check_query);
$user = mysqli_fetch_assoc($result);
if (move_uploaded_file($_FILES['img']['tmp_name'], $target)) {
  		echo'profile pic submitted';
  	}
if ($user) { // if user exists
if ($user['username'] === $username) {
array_push($errors, "Username already exists");
}
if ($user['email'] === $email) {
array_push($errors, "email already exists");
}
}
// Finally, register user if there are no errors in the form
if (count($errors) == 0) {
	
$password = md5($password_1);//encrypt the password before saving in the database
echo $password ;
$query = "INSERT INTO users(username, email, password,photo)
VALUES('$username', '$email', '$password','$image')";
mysqli_query($wmdb, $query);
$_SESSION['username'] = $username;
$_SESSION['success'] = "You are now registered in";
header('location: login.php');
}
}
//login files below
// LOGIN USER
if (isset($_POST['log_user'])) {
$username = mysqli_real_escape_string($wmdb, $_POST['username']);
$password = mysqli_real_escape_string($wmdb, $_POST['password']);
if (empty($username)) {
array_push($errors, "Username is required");
}
if (empty($password)) {
array_push($errors, "Password is required");
}
if (count($errors) == 0) {
$password = md5($password);
$query = "SELECT * FROM users WHERE username='$username' AND password='$password'";
$results = mysqli_query($wmdb, $query);
if (mysqli_num_rows($results) == 1) {
$_SESSION['username'] = $username;
$_SESSION['success'] = "You are now logged in";
//after all the conditions are met and confirmed to be true ! now redirect to your page
//ypu just have to change ther index.php to the name of your dashboard 
header('location: index.php');
}else {
array_push($errors, "Wrong username/password combination");
}
}
}

// handle blog uplads here and image uploads
 $msg = "";

  // If upload button is clicked ...
  if (isset($_POST['publish'])) {
  	// Get image name
  	$image = $_FILES['img']['name'];
  	// Get text
  	$headline = mysqli_real_escape_string($wmdb, $_POST['headliner']);
  	$post = mysqli_real_escape_string($wmdb, $_POST['poster']);
  	$categ = mysqli_real_escape_string($wmdb, $_POST['categorizer']);
  	 $text_area = mysqli_real_escape_string($wmdb, $_POST['area']);
  	 $time_posted= date('Y-m-d h:i:s:a');
  	// image file directory
  	$target = "uploads/".basename($image);//this will be the file where we wish to upload our posts!! make sure this folder exists, id not , create one 

  	$sql = "INSERT INTO blogs (headline,posted_by,category,post,date,photo) VALUES ('$headline','$post','$categ','$text_area','$time_posted','$image')";
  	// execute query
  	mysqli_query($wmdb, $sql);

  	if (move_uploaded_file($_FILES['img']['tmp_name'], $target)) {
  		echo'';
  		header("Refresh:1; blog_post.php");
  	}else{
  		$msg = "Failed to upload post";
  	}
  }
  //end blog upload here
  //function to fetch data from the blogs and display it in a table
  //there are other ways you can display in the fields but i prefer putting them in a function for future editing!!
  function image(){
  	include 'includes/connector.php';
 
  	$sql=mysqli_query($wmdb,"SELECT * FROM blogs ORDER BY id DESC LIMIT 3");
  	
  	foreach ($sql as $key => $wmdashboard) {
  		# code...
  		//note! if the table appears distorted in any way! maybe there might be a problem with the div classes that you have used
  		echo'   
                            <div class="col-md-4 flip-card stretch-card grid-margin">
                                <div class="overview-item overview-item--c1 flip-card-inner rounded">
                                    <div class="overview__inner flip-card-front rounded"><a href="bloglist.php"><img src="uploads/'.$wmdashboard['photo'].'" class="rounded" style="width:300px;height:300px;" alt="image" style="width:100px; height:100px;"/></a></div>
                                        <div class="overview-box clearfix flip-card-back rounded">
                                

                                        
                                            <div class="icon">
                                                <i class="zmdi zmdi-account-o"></i>
                                            </div>
                                            <div class="text">
                                            <br />
                                                <h1 class="badge badge-primary">'.$wmdashboard['category'].'</h1> 
      <p>'.$wmdashboard['post'].'</p> 
     <p class="badge badge-success">'.$wmdashboard['date'].'</p>
     <a href="blogedit.php?edit='.$wmdashboard['id'].'"> <button type="button" class="btn btn-gradient-primary btn-rounded btn-icon" name="edit"> <i class="mdi mdi-table-edit"></i></button></a>
     <a href="inserts.php?del='.$wmdashboard['id'].'">  <button type="button" class="btn btn-gradient-danger btn-rounded btn-icon" name="del"> <i class="mdi mdi-delete-variant"></i></button></a>
                                            </div>
                                        </div>
                                        <div class="overview-chart flip-card-inner rounded">
<span class="badge badge-info"> '.$wmdashboard['headline'].'</span>
<span class="badge badge-success" style="border-bottom-left-radius:20px; border-top-right-radius:20px;"> '.$wmdashboard['category'].'</span>
                                        </div>
                                    </div>
                                </div>
                           ';
  }}
  function bloglist(){
  	include 'includes/connector.php';
 
  	$sql=mysqli_query($wmdb,"SELECT * FROM blogs ORDER BY id DESC LIMIT 10");
  	
  	foreach ($sql as $key => $wmdashboard) {
  		# code...
  		//note! if the table appears distorted in any way! maybe there might be a problem with the div classes that you have used
  		echo' <tbody>
                        <tr>
                          <td class="py-1">
                            <img src="uploads/'.$wmdashboard['photo'].'" class="rounded" alt="image" style="width:100px; height:100px;"/>
                          </td>
                          <td> <span class="badge badge-info"> '.$wmdashboard['headline'].'</span></td>
                          <td>
                            <button class="btn-gradient-primary btn-sm"> '.$wmdashboard['posted_by'].'</button>
                          </td>
                          <td> <span class="badge badge-success" style="border-bottom-left-radius:20px; border-top-right-radius:20px;"> '.$wmdashboard['category'].'</span></td>
                          <td> '.$wmdashboard['date'].'</span></td>
                          <td> <a href="blogedit.php?edit='.$wmdashboard['id'].'"><button type="button" class="btn btn-gradient-primary btn-rounded btn-icon" name="edit">
                            <i class="mdi mdi-table-edit"></i>
                          </button>
                          </a>
                          <a href="inserts.php?del='.$wmdashboard['id'].'"> <button type="button" class="btn btn-gradient-danger btn-rounded btn-icon" name="del">
                            <i class="mdi mdi-delete-variant"></i>
                          </button></a>
                          </td>
                        </tr></tbody>';
  	}
  }
//updateblog here


  if (isset($_POST['update'])) {
  	$message="";
  	$id = $_POST['id'];
  	$image=$_POST['img'];
  	$time_posted= date('Y-m-d h:i:s:a');
  	$headline = $_POST['headliner'];
	$posted = $_POST['poster'];
	$post=$_POST['area'];
	$cat=$_POST['categorizer']; 
  mysqli_query($wmdb, "UPDATE blogs SET headline='$headline', posted_by='$posted',,post='$post',date='$time_posted',category='$cat' WHERE id=$id");
  $_SESSION['message'] = "blog updated!"; 
  header('location: bloglist.php');
}

//delete blog records
if (isset($_GET['del'])) {
	$id = $_GET['del'];
	mysqli_query($wmdb, "DELETE FROM blogs WHERE id=$id");
	$message = "Address deleted!"; 
	header('location: bloglist.php');
}
//change themes here
if(isset($_POST['themer'])){
  $wmchanger = mysqli_real_escape_string($wmdb, $_POST['wahome']);
  $wmcheck= "INSERT INTO theme(name) VALUES ('$wmchanger')";
  $result=mysqli_query($wmdb,$wmcheck);
  if ($result) {
    # code...
    header("Refresh:1; url=index.php");
  }
}
//done with inserting
//now make a function to display it to the front end and change the theme
//as i like doing we will add the themes manually in a select but linking it to the css we will do it in a function thqt will fetch the names from the database and display add them to the link
function themelink(){
  include 'includes/connector.php';
  $sql=mysqli_query($wmdb,"SELECT * FROM theme ORDER BY id DESC LIMIT 1");
  foreach($sql AS $wm => $wmchecker){
    echo ' <link rel="stylesheet" href="assets/css/'.$wmchecker['name'].'.css">';
  }
}
//now lets make the function that will display active themes
              function active(){
                include 'includes/connector.php';
                $result=mysqli_query($wmdb,"SELECT * FROM theme ORDER BY id DESC LIMIT 1");
                foreach ($result as $key => $value) {
                  # code...
                  echo '<div><span class="badge badge-success" style="border-radius: 20px;">'.$value['name'].'</span></div>';
                }
              }

              //lets count table records
              function blogR(){
                include 'includes/connector.php';
                $rec=mysqli_query($wmdb,"SELECT * FROM blogs");
                $result=mysqli_num_rows($rec);
                echo $result;
              }
              ?>
 