<?php include'includes/header.php';
include 'includes/connector.php';?>

<?php
  //let us create the actions buttons(delete,edit and view buttons) still inside the function
    //let's declare some variables here
    $id=0;
    $update = false;

if (isset($_GET['edit'])) {
		$id = $_GET['edit'];
		$update = true;
		$record = mysqli_query($wmdb, "SELECT * FROM blogs WHERE id=$id");

		if (@count($record) == 1 ) {
			//this will let us add these to a form so that we can edit the post easily
			$n = mysqli_fetch_array($record);
			$image=$n['photo'];
			$headline = $n['headline'];
			$posted = $n['posted_by'];
			$post=$n['post'];
			$cat=$n['category']; 
	
		echo'
                      <form class="forms-sample" action="inserts.php" method="POST" enctype="multipart/form-data"> <div class="form-group">
                        <label for="exampleInputName1">Headline</label>
                        <input type="hidden" name="headliner" class="form-control shadow p-3  rounded" id="exampleInputName1"  value='.$id.'>
                      </div>
                       <div class="form-group">
                        <label for="exampleInputName1">Posted by</label>
                        <input type="text" class="form-control shadow p-3  rounded" name="poster" id="exampleInputName2" value='.$headline.'>
                      </div>
                      <div class="form-group">
                        <label for="exampleSelectGender">Category</label>
                        <select class="form-control shadow p-3  rounded" name="categorizer" id="exampleSelectGender" value='.$cat.'>
                          <option>Love</option>
                          <option>Hate</option>
                        </select>
                      </div>
                      <div class="form-group">
                        <label>image upload</label>
                        <input type="file" name="img" class="file-upload-default shadow p-3  rounded" value='.$image.'>
                        <div class="input-group col-xs-12">
                          <input type="text" class="form-control file-upload-info shadow p-3  rounded" disabled placeholder="Upload Image">
                          <span class="input-group-append">
                            <button class="file-upload-browse btn btn-gradient-primary shadow p-3  rounded" type="button">Upload</button>
                          </span>
                        </div>
                      </div>
                      <div class="form-group">
                        <label for="exampleTextarea1">Textarea</label>
                        <textarea class="textarea shadow p-3  rounded" value='.$post.'
                          style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;" name="area"></textarea> 
                      </div>
                      <button type="submit" class="btn btn-gradient-primary mr-2" name="update" id="jim">update</button>
                      <button class="btn btn-light">Cancel</button>
                    </form>';
	}}



  ?>
  <?php include 'includes/footer.php';?>