<?php include "includes/header.php";?>
 <div class="row" style="overflow-x:auto;">
                <div class="col-12 grid-margin stretch-card">
                  <div class="card-body">
                    
                    <table class="table table-striped">
                      <thead>
                        <tr>
                          <th>Image &nbsp <i class="mdi mdi-folder-multiple-image btn btn-gradient-primary btn-rounded btn-icon"></i></th>
                          <th> Headline &nbsp <i class="mdi mdi-blogger btn btn-gradient-primary btn-rounded btn-icon"></i></th>
                          <th> Posted by  &nbsp <i class="mdi mdi-account-circle btn btn-gradient-primary btn-rounded btn-icon"></i></th>
                          <th> Category &nbsp <i class="mdi mdi-book-plus btn btn-gradient-primary btn-rounded btn-icon"></i></th>
                          <th> date  &nbsp <i class="mdi mdi-calendar-clock btn btn-gradient-primary btn-rounded btn-icon"></i></th>
                          <th>actions &nbsp <i class="mdi mdi-fingerprint btn btn-gradient-primary btn-rounded btn-icon"></i></th>
                        </tr>
                      </thead>
                      <!--here we call the function we wrote in  the insetrs.php to display the table! note that we have the table heads in this page and not in the function! this is to mnake sure that it appears only once and does not keep on repeating itself all the time-->
                      <?php echo bloglist();?>
                    </table></div></div></div>
                 
<?php include "includes/footer.php";?>