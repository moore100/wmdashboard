<?php
$hostserver="localhost";
$hostuser="root";
$password="";
$dbname="wmdashboard";
$wmdb=mysqli_connect($hostserver,$hostuser,$password,$dbname) or die("conneaction could not established");
if(!$wmdb){
	echo '<div>No Connection  Could Be Established</div>';
}
?>