<?php include 'includes/header.php';?>
  <div class="row">
   <div class="col-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title">Publish Your Post!</h4>
                    <form class="forms-sample" action="inserts.php" method="POST" enctype="multipart/form-data">
                      <div class="form-group">
                        <label for="exampleInputName1">Headline</label>
                        <input type="text" name="headliner" class="form-control shadow p-3  rounded" id="exampleInputName1" placeholder="Name">
                      </div>
                       <div class="form-group">
                        <label for="exampleInputName1">Posted by</label>
                        <input type="text" class="form-control shadow p-3  rounded" name="poster" id="exampleInputName2" placeholder="Name">
                      </div>
                      <div class="form-group">
                        <label for="exampleSelectGender">Category</label>
                        <select class="form-control shadow p-3  rounded" name="categorizer" id="exampleSelectGender">
                          <option>Love</option>
                          <option>Hate</option>
                        </select>
                      </div>
                      <div class="form-group">
                        <label>image upload</label>
                        <input type="file" name="img" class="file-upload-default shadow p-3  rounded" >
                        <div class="input-group col-xs-12">
                          <input type="text" class="form-control file-upload-info shadow p-3  rounded" disabled placeholder="Upload Image">
                          <span class="input-group-append">
                            <button class="file-upload-browse btn btn-gradient-primary shadow p-3  rounded" type="button">Upload</button>
                          </span>
                        </div>
                      </div>
                      <div class="form-group">
                        <label for="exampleTextarea1">Textarea</label>
                        <textarea class="textarea shadow p-3  rounded" placeholder="Place some text here"
                          style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;" name="area"></textarea> 
                      </div>
                      <button type="submit" class="btn btn-gradient-primary mr-2" name="publish" id="jim" onclick="document.getElementById('jim').innerHTML='...publishing...'">Submit</button>
                      <button class="btn btn-light">Cancel</button>
                    </form>
                  </div>
                </div>
              </div>
</div>
    <?php include "includes/footer.php";?>